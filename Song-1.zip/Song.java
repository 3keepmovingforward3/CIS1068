
/*
Benjamin Blouin
2019/02/04
Assignment 2. Song

This program outputs to console a given shortened
classic American folk song named, Bought Me a Cat.

*/
public class Song {


    public static void main(String[] args) {

        /*
        Animals in the poem
         */
        String cat   = "cat";
        String hen   = "hen";
        String duck  = "duck";
        String goose = "goose";
        String sheep = "sheep";
        String pig   = "pig";

        /*
        * Overloaded verses method in order given from poem
        */

        verse(cat);
        verse(cat, hen);
        verse(cat, hen, duck);
        verse(cat, hen, duck, goose);
        verse(cat, hen, duck, goose, sheep);
        verse(cat, hen, duck, goose, sheep, pig);
    }

    private static void baaBaa(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1) + " goes baa, baa,");
    }

    private static void boughtMe(String animal) {
        System.out.println("Bought me a " + animal + " and the " + animal + " pleased me,");
    }

    private static void chimmyChunk(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1)
                + " goes chimmy-chuck, chimmy-chuck,");
    }

    private static void goesFiddle(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1) + " goes fiddle-i-fee.");
    }

    private static void hissy(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1) + " goes hissy, hissy,");
    }

    private static void iFed(String animal) {
        System.out.println("I fed my " + animal + " under yonder tree.");
    }

    private static void oink(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1) + " goes oink, oink,");
    }

    private static void quack(String animal) {
        System.out.println(animal.substring(0, 1).toUpperCase() + animal.substring(1) + " goes quack, quack,");
    }

    private static void nl() {
        System.out.println();
    }

    private static void verse(String animal) {
        boughtMe(animal);
        iFed(animal);
        goesFiddle(animal);
        nl();
    }

    private static void verse(String animal, String animal2) {
        boughtMe(animal2);
        iFed(animal2);
        chimmyChunk(animal2);
        goesFiddle(animal);
        nl();
    }

    private static void verse(String animal, String animal2, String animal3) {
        boughtMe(animal3);
        iFed(animal3);
        quack(animal3);
        chimmyChunk(animal2);
        goesFiddle(animal);
        nl();
    }

    private static void verse(String animal, String animal2, String animal3, String animal4) {
        boughtMe(animal4);
        iFed(animal4);
        hissy(animal4);
        quack(animal3);
        chimmyChunk(animal2);
        goesFiddle(animal);
        nl();
    }

    private static void verse(String animal, String animal2, String animal3, String animal4, String animal5) {
        boughtMe(animal5);
        iFed(animal5);
        baaBaa(animal5);
        hissy(animal4);
        quack(animal3);
        chimmyChunk(animal2);
        goesFiddle(animal);
        nl();
    }

    private static void verse(String animal, String animal2, String animal3, String animal4, String animal5,
                              String animal6) {
        boughtMe(animal6);
        iFed(animal6);
        oink(animal6);
        baaBaa(animal5);
        hissy(animal4);
        quack(animal3);
        chimmyChunk(animal2);
        goesFiddle(animal);
    }
}