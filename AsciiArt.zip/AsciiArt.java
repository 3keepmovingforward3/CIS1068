/*
Benjamin Blouin
2019/01/30
Assignment 3. Draw a Pretty Picture

Draw something pretty using ASCII art.

*/

public class AsciiArt {

    static final int SIZE=50; //Controls overall diamond size
    static final char STAR='*'; //Reassign string literals for ease of loop understanding
    static final char SPACE=' ';
    static final char NEWLINE='\n';

    public static void main(String[] args) {
        checkSize();
        patternStart();

    }

    //Because at some point the pattern is too big to be seen/displayed in a window coherently
    private static void checkSize() {
        if (SIZE>100){
            System.out.println("SIZE is too big.");
            System.exit(1);
        }
    }

    private static void patternStart(){
        int i;
        int j;
        int k;

        //Outer loop controls number of diamonds displayed
        for(k=0;k<2;k++) {

            //Upper
            for (i = 1; i <= SIZE; i++) {
                for (j = SIZE - 1; j >= i; j--) {
                    System.out.print(SPACE);
                }
                System.out.print(STAR);
                for (j = 1; j < (i - 1) * 2; j++) {
                    System.out.print(SPACE);
                }
                if (i > 1) {
                    System.out.print(STAR);
                }
                System.out.print(NEWLINE);
            }

            //Lower
            for (i = SIZE - 1; i >= 1; i--) {
                for (j = SIZE - 1; j >= i; j--) {
                    System.out.print(SPACE);
                }
                System.out.print(STAR);
                for (j = 1; j < (i - 1) * 2; j++) {
                    System.out.print(SPACE);
                }
                if (i > 1) {
                    System.out.print(STAR);
                }
                System.out.print(NEWLINE);
            }
        }
    }
}
