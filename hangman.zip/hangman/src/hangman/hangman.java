package hangman;

import java.util.Scanner;

/**
 * @author bblouin
 * @
 */

public class hangman {

    public static void main(String[] args) {
        String userGuesses;
        boolean i=false;

        // Scanner for input
        Scanner k = new Scanner(System.in);
        // Where all the computation is done
        computer c = new computer();

        // hangman visualizations
        hangmanVisual t = new hangmanVisual();
        // print rules
        t.printRules();
        // print gallows
        t.initGallows();
        // print initial spaces
        t.printSpaces(c.getLevel());

        while (c.getHangmanStatus()<=6) {
            // user prompt
            System.out.print("Enter guess: ");
            // user input char or string
            userGuesses = k.nextLine();
            //remove matches method
            c.removeMatchCharacter(userGuesses);
            // print hangman pieces by knowing what guess user's on
            t.hangmanVisualControl(c.getHangmanStatus());
            if(c.getHangmanStatus()==0 || c.getCheat()){t.printSpaces(c.getLevel());}
        }
        if(i=false){t.hangmanVisualControl(6);t.hangmanVisualControl(7);}
        else if (i){t.winnerOut();}
        c.getAnswerChoice();

    }
}