package hangman;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class computer extends hangman {
    private Random randLength = new Random();
    private int level;
    private boolean cheat;
    private ArrayList<String> answerList;
    private ArrayList<String> listWords;
    private String currentAnswer;
    private int hangmanStatus;
    private ArrayList<Character> userGuesses = new ArrayList<>();
    boolean cont = true;


    computer() {
        setCheat(true);
        this.listWords = initWordList();
        this.level = setRandLength();
        this.answerList = setAnswerList();
        this.hangmanStatus = 0;
    }

    private int setRandLength() {
        return randLength.nextInt(Collections.max(getListWords(), Comparator.comparing(String::length)).length()) +
                Collections.min(getListWords(), Comparator.comparing(String::length)).length();
    }

    boolean getCheat() {
        return cheat;
    }

    private void setCheat(boolean cheat) {
        this.cheat = cheat;
    }

    private ArrayList<String> initWordList() {

        String fileName = "word_list.txt";
        try (BufferedReader br = Files.newBufferedReader(Paths.get(fileName))) {
            //br returns as stream and convert it into a List
            return br.lines().collect(Collectors.toCollection(ArrayList::new));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private ArrayList<String> getListWords() {
        return listWords;
    }

    private ArrayList<String> setAnswerList() {
        Comparator<String> f = Comparator.comparing(String::length);
        Predicate<String> lesserThan = i -> (i.length() < level);
        Predicate<String> moreThan = i -> (i.length() > level);
        this.listWords.sort(f);
        this.listWords.removeIf(lesserThan);
        this.listWords.removeIf(moreThan);
        return listWords;
    }

    int getHangmanStatus() {
        return hangmanStatus;
    }

    private void setHangmanStatus(int hangmanStatus) {
        this.hangmanStatus = hangmanStatus;
    }

    int getLevel() {
        return this.level;
    }

    void getAnswerChoice() {
        if (this.currentAnswer == null) {
            this.currentAnswer = this.answerList.get(0);
        }
        System.out.println("Answer is: " + this.currentAnswer);
    }

    //TODO check this logic
    void removeMatchCharacter(String userGuess) {
        boolean r = false;
        Predicate<String> hasCharacter = i -> (i.contains(userGuess));

        // using to check if predicate makes empty
        if(currentAnswer==null) {
            ArrayList<String> temp = new ArrayList<>(answerList);
            boolean t = temp.removeIf(hasCharacter);
            if (temp.isEmpty() && cont) {
                setCheat(false); // since we can't cheat anymore
                this.currentAnswer = answerList.get(0); //get string at index save to currentanswer
                this.userGuesses = new ArrayList<>(Collections.nCopies(currentAnswer.length(), ' '));
                cont = false;
            }
        }
        // if still cheating
        if (getCheat() && cont) {
            this.answerList.removeIf(hasCharacter);
            setHangmanStatus(getHangmanStatus() + 1);
        }
        // if not cheating
        else {
            if (!getCheat()) {
                cont = true;
                int e = 0;
                while(cont) {
                    this.userGuesses.set(this.currentAnswer.indexOf(userGuess), this.currentAnswer.charAt(this.currentAnswer.indexOf(userGuess)));
                    try{
                    e = this.currentAnswer.indexOf(this.currentAnswer.charAt(this.currentAnswer.indexOf(userGuess)), this.currentAnswer.indexOf(userGuess)+1);
                        this.userGuesses.set(e, this.currentAnswer.charAt(this.currentAnswer.indexOf(e)));
                    }
                catch(IndexOutOfBoundsException exception){
                    cont=false;
                    }

                    for (int k = 0; k < currentAnswer.length(); k++) {
                        if (userGuesses.get(k).equals(' ')) {
                            System.out.print(" _ ");
                        } else if (this.currentAnswer.indexOf(this.currentAnswer.charAt(this.currentAnswer.indexOf(userGuess)), this.currentAnswer.indexOf(userGuess))!=-1)

                            System.out.print(" " + this.currentAnswer.charAt(k) + " ");
                    }
                    cont = false;
                }
            }
        }


        }

        boolean checkWinner() {
            String listString = userGuesses.stream().map(e->e.toString()).reduce((acc, e) -> acc  + e).get();
        return currentAnswer.contentEquals(userGuesses.toString());
        }
}

