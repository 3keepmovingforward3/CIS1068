// Benjamin Blouin
// 2019/01/14
// Assignment 1. Greetings
//
// This program outputs to console salutations to new professor
//

public class Main {

    public static void main(String[] args) {
        System.out.println("Good morning, Professor Fiore.");
    }
}
